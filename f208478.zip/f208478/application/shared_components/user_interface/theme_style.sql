prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 208478
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38422178159124110674
,p_default_application_id=>208478
,p_default_id_offset=>38766093974777590157
,p_default_owner=>'WKSP_TECWORKSPACE'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(38769437640164394179)
,p_theme_id=>42
,p_name=>'Redwood Light'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Redwood-Theme#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2596426436825065489
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(38769437997090394179)
,p_theme_id=>42
,p_name=>'Vita'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2719875314571594493
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(38769438411300394180)
,p_theme_id=>42
,p_name=>'Vita - Dark'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Dark.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Dark#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3543348412015319650
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(38769438819026394180)
,p_theme_id=>42
,p_name=>'Vita - Red'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Red.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Red#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>1938457712423918173
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(38769439205266394180)
,p_theme_id=>42
,p_name=>'Vita - Slate'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Slate.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Slate#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3291983347983194966
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(38816338041431761745)
,p_theme_id=>42
,p_name=>'APEXToGo'
,p_is_current=>true
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Accent-BG":"#c13c1e","@g_Button-BorderRadius":"24px","@g_Form-BorderRadius":"4px","@g_Color-Palette-1":"#c13c1e","@g_Color-Palette-1-FG":"#ffffff","@g_Color-Palette-2":"#c33b12","@g_Color-Palette-2-FG":"#e4f9fd","@g_Color-Pa'
||'lette-3":"#af4a2b","@g_Color-Palette-3-FG":"#f0fcfb","@g_Color-Palette-4":"#a85941","@g_Color-Palette-4-FG":"#f0faf6","@g_Color-Palette-5":"#b8715c","@g_Color-Palette-5-FG":"#ffffff","@g_Color-Palette-6":"#cc4319","@g_Color-Palette-6-FG":"#2a2a08","@'
||'g_Container-BorderRadius":"14px","@g_Nav_Style":"light","@g_Nav-Accent-BG":"#e53500","@g_Nav-Accent-FG":"#ffffff","@Nav-Exp":"340px","@g_Body-Content-Max-Width":"100%","@Actions-Exp":"360px","@Head-Height":"56px","@g_Nav-BG":"#ffffff","@g_Nav-FG":"#3'
||'33333","@g_Nav-Icon":"#333333","@g_Nav-Icon-Active":"#050505","@g_Disabled-BG":"#707070","@g_Disabled-FG":"#FFFFFF","@g_Button-BG":"#f8f8f8","@g_Button-Text":"#383838","@g_Focus":"#e8684c","@g_Form-Item-BG":"#f9f9f9","@g_Form-Item-FG":"#211e1e","@g_A'
||'ccent-OG":"#fdfdfd","@g_Header-BG":"#ffffff","@g_Header-FG":"#000000","@l_Button-Hot-BG":"#c13c1e","@l_Button-Hot-Text":"#ffffff","@g_Nav-Badge-BG":"#de5435","@g_Nav-Badge-FG":"#ffffff","@g_Link-Base":"#c13c1e"},"customCSS":".t-Login-header {\n    di'
||'splay: none;\n}\n\n.t-Region-header {\n    display: none;\n}\n\n.t-Header-branding {\n    display: none;\n}\n\n.apex-region-calendar {\n    height: calc(100vh - 200px);\n\n}\n","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#38816338041431761745.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
