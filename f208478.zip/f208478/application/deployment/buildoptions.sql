prompt --application/deployment/buildoptions
begin
--   Manifest
--     INSTALL BUILD OPTIONS: 208478
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38422178159124110674
,p_default_application_id=>208478
,p_default_id_offset=>38766093974777590157
,p_default_owner=>'WKSP_TECWORKSPACE'
);
null;
wwv_flow_imp.component_end;
end;
/
