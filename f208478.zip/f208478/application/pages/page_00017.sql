prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38422178159124110674
,p_default_application_id=>208478
,p_default_id_offset=>38766093974777590157
,p_default_owner=>'WKSP_TECWORKSPACE'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_name=>'HomeTest'
,p_alias=>'HOMETEST'
,p_step_title=>'HomeTest'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Categories */',
'.c-Categories {',
'  --a-cv-placeholder-color: transparent; /* Hide Placeholders */',
'  --a-cv-background-color: transparent; /* Remove Card Background */',
'  --a-cv-border-width: 0px; /* Remove Card Borders */',
'  --a-cv-header-padding-y: .5rem;',
'  --a-cv-title-font-size: .875rem;',
'  --a-cv-title-font-weight: 400;',
'  --a-cv-shadow: none;',
'  --a-cv-icon-image-size: 4rem;',
'',
'  min-block-size: 8rem; /* Set Initial Size of Cards */',
'}',
'',
'/* Align Category Image */',
'.c-Categories .a-CardView-iconImg {',
'  margin-inline: auto;',
'}',
'',
'/* Misc Category Styles */',
'.c-Categories .a-CardView-items {',
'  padding-inline: .25rem;',
'  padding-block: 0;',
'  margin-inline: auto;',
'  text-align: center;',
'  inline-size: max-content;',
'}',
'',
'/* Misc Category Item Styles */',
'.c-Categories .a-CardView-item {',
'  flex-shrink: 0;',
'  padding-block: .5rem;',
'  min-inline-size: 0;',
'}',
'',
'/* Set Carousel Aspect Ratio */',
'.t-Region-carouselRegions {',
'  aspect-ratio: 2.5 / 1;',
'  overflow: hidden;',
'}',
'',
'/* Cards */',
'.a-CardView-items {',
'  max-inline-size: 100%;',
'  scrollbar-width: 0;',
'  scroll-snap-type: x mandatory;',
'  overflow-x: auto;',
'  display: flex;',
'  flex-wrap: nowrap;',
'}',
'',
'/* Hide Scrollbars for Webkit Browsers */',
'.a-CardView-items::-webkit-scrollbar {',
'  display: none;',
'}',
'',
'.a-CardView-item {',
'  scroll-snap-align: start;',
'  min-inline-size: 17.5rem;',
'}',
'',
'/* Rating Badge */',
'.a-CardView-badge {',
'  background-color: var(--a-palette-warning-shade);',
'  color: var(--a-palette-warning);',
'}',
'',
'.a-CardView-badgeValue {',
'  color: initial;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38789047024952532004)
,p_plug_name=>'Habits'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38897949423731851620)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'ARCHEOTYPES'
,p_include_rowid_column=>false
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(38789047181614532005)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(38789048156365532015)
,p_name=>'ARCH_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ARCH_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(38789048275296532016)
,p_name=>'ARCH_DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ARCH_DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp.component_end;
end;
/
