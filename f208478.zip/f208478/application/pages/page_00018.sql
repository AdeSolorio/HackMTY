prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38422178159124110674
,p_default_application_id=>208478
,p_default_id_offset=>38766093974777590157
,p_default_owner=>'WKSP_TECWORKSPACE'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_name=>'Archetypes'
,p_alias=>'ARCHETYPES'
,p_step_title=>'Archetypes'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38810275353716169294)
,p_plug_name=>'Archetypes'
,p_title=>'Archetypes'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38897937664988851604)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       DESCRIPTION,',
'       COLOR,',
'       IMAGE,',
'       BLOLB,',
'       MIME,',
'       CREATED_DATE,',
'       FILE_NAME,',
'       ''#APP_FILES#'' || IMAGE_SIMPLE AS image_url',
'  from ARCHETYPES'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(38810275812245169294)
,p_region_id=>wwv_flow_imp.id(38810275353716169294)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'DESCRIPTION'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'&IMAGE_URL.'
,p_media_display_position=>'FIRST'
,p_media_sizing=>'FIT'
,p_media_description=>'&NAME.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38842758303978882508)
,p_plug_name=>'Title'
,p_title=>'Select your archetype!'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useRegionTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38898009539284851670)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_HELP_TEXT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38842758913592882514)
,p_name=>'CHECK2'
,p_item_sequence=>20
,p_prompt=>'Check2'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Prosperous;Prosperous,Balancer;Balancer,Ecoist;Ecoist,Fitness;Fitness,Taskmaster;Taskmaster,Refresher;Refresher,Networker;Networker'
,p_field_template=>wwv_flow_imp.id(38898067871155851710)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp.component_end;
end;
/
