prompt --application/pages/page_09999
begin
--   Manifest
--     PAGE: 09999
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38422178159124110674
,p_default_application_id=>208478
,p_default_id_offset=>38766093974777590157
,p_default_owner=>'WKSP_TECWORKSPACE'
);
wwv_flow_imp_page.create_page(
 p_id=>9999
,p_name=>'Sign In'
,p_alias=>'LOGIN'
,p_step_title=>'APEXToGo - Sign In'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Setting the Logo to be Larger on Mobile */',
'.c-SplashBox {',
'  --ut-xs-hero-region-icon-container-size: 8rem;',
'  --ut-xs-hero-region-title-font-size: 2rem;',
'  --ut-xs-hero-region-title-line-height: 2.5rem;',
'  --ut-hero-region-icon-container-size: 8rem;',
'  --ut-hero-region-icon-size: 4rem;',
'}'))
,p_step_template=>wwv_flow_imp.id(38897905198865851559)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38987154907586141682)
,p_plug_name=>'Background Image'
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(38897967328774851637)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BACKGROUND_IMAGE'
,p_location=>null
,p_region_image=>'#APP_FILES#back2.png'
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39374046341191924860)
,p_plug_name=>'Archetypes'
,p_region_css_classes=>'c-SplashBox mxw480 margin-auto'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured t-HeroRegion--centered'
,p_plug_template=>wwv_flow_imp.id(38897963808510851634)
,p_plug_display_sequence=>10
,p_location=>null
,p_region_image=>'#APP_FILES#icons/app-icon-192.png'
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38898184987946851947)
,p_button_sequence=>70
,p_button_name=>'SIGNIN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--large:t-Button--stretch:t-Button--padTop:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(38898070284701851712)
,p_button_image_alt=>'Sign In'
,p_button_css_classes=>'mxw320 margin-auto'
,p_grid_new_row=>'Y'
,p_grid_column_span=>4
,p_grid_column=>5
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38789048709861532021)
,p_button_sequence=>80
,p_button_name=>'REGISTER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--tiny:t-Button--stretch:t-Button--padTop:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(38898070284701851712)
,p_button_image_alt=>'Register'
,p_button_redirect_url=>'f?p=&APP_ID.:20020:&SESSION.::&DEBUG.:::'
,p_grid_new_row=>'Y'
,p_grid_column_span=>4
,p_grid_column=>5
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38789048987949532023)
,p_name=>'P9999_PASSWORD'
,p_is_required=>true
,p_item_sequence=>40
,p_prompt=>'Password'
,p_placeholder=>'Enter password'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>16
,p_grid_column_css_classes=>'mxw320 margin-auto'
,p_field_template=>wwv_flow_imp.id(38898067871155851710)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:margin-top-none:margin-bottom-sm'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38898183417484851945)
,p_name=>'P9999_USERNAME'
,p_is_required=>true
,p_item_sequence=>30
,p_prompt=>'Username'
,p_placeholder=>'Enter username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>100
,p_grid_column_css_classes=>'mxw320 margin-auto'
,p_field_template=>wwv_flow_imp.id(38898067871155851710)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:margin-top-none:margin-bottom-sm'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38775194993201685765)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Set Username Cookie'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'SEND_LOGIN_USERNAME_COOKIE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>9101018424095608
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(38775195145604685766)
,p_page_process_id=>wwv_flow_imp.id(38775194993201685765)
,p_page_id=>9999
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9999_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(38775195269358685767)
,p_page_process_id=>wwv_flow_imp.id(38775194993201685765)
,p_page_id=>9999
,p_name=>'p_cookie_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>20
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(38775195309767685768)
,p_page_process_id=>wwv_flow_imp.id(38775194993201685765)
,p_page_id=>9999
,p_name=>'p_consent'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38775194415182685759)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Login'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'LOGIN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>9100440405095602
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(38775194556437685760)
,p_page_process_id=>wwv_flow_imp.id(38775194415182685759)
,p_page_id=>9999
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'FUNCTION_BODY'
,p_value_language=>'PLSQL'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P9999_USERNAME is not null then',
'    return :P9999_USERNAME;',
'else',
'    return ''demo'' || :APP_SESSION;',
'end if;'))
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(38775194589155685761)
,p_page_process_id=>wwv_flow_imp.id(38775194415182685759)
,p_page_id=>9999
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(38775194870013685763)
,p_page_process_id=>wwv_flow_imp.id(38775194415182685759)
,p_page_id=>9999
,p_name=>'p_set_persistent_auth'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'STATIC'
,p_value=>'TRUE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38775194912210685764)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Page(s) Cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>9100937433095607
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(40666422669246476558)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_process_sql_clob=>':P9999_USERNAME := apex_authentication.get_login_username_cookie;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>1900328694468886401
);
wwv_flow_imp.component_end;
end;
/
