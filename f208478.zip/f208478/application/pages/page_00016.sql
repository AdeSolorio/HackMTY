prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38422178159124110674
,p_default_application_id=>208478
,p_default_id_offset=>38766093974777590157
,p_default_owner=>'WKSP_TECWORKSPACE'
);
wwv_flow_imp_page.create_page(
 p_id=>16
,p_name=>'Stats'
,p_alias=>'STATS'
,p_step_title=>'Stats'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38775413246238842325)
,p_plug_name=>'Habits achieved'
,p_title=>'Habits achieved'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38897997171854851661)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_header=>'Habits achieved'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(38775413640452842326)
,p_region_id=>wwv_flow_imp.id(38775413246238842325)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(38775415317926842328)
,p_chart_id=>wwv_flow_imp.id(38775413640452842326)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    (COUNT(HL.ID) / (SELECT COUNT(H.ID) FROM "HABITS" H)) * 100 AS "HABIT_PERCENTAGE",',
'    TO_CHAR(HL.COMPLETED_ON, ''DD/MM/YY'') AS "COMPLETED_ON"',
'FROM ',
'    "HABIT_LOGS" HL',
'GROUP BY ',
'    HL.COMPLETED_ON;'))
,p_max_row_count=>20
,p_items_value_column_name=>'HABIT_PERCENTAGE'
,p_items_label_column_name=>'COMPLETED_ON'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(38775414141628842326)
,p_chart_id=>wwv_flow_imp.id(38775413640452842326)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(38775414791030842327)
,p_chart_id=>wwv_flow_imp.id(38775413640452842326)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38775415986196842328)
,p_plug_name=>'Habits (Last 21 days)'
,p_title=>'Habits (Last 21 days)'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38897997171854851661)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_header=>'Habits (Last 21 days)'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(38775416360980842328)
,p_region_id=>wwv_flow_imp.id(38775415986196842328)
,p_chart_type=>'pie'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(38775416873695842329)
,p_chart_id=>wwv_flow_imp.id(38775416360980842328)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    H.NAME AS "HABIT_NAME",',
'    COUNT(HL.ID) AS "HABIT_TOTAL"',
'FROM ',
'    "HABIT_LOGS" HL',
'JOIN ',
'    "HABITS" H ON HL.HABIT_ID = H.ID',
'WHERE ',
'    HL.COMPLETED_ON >= SYSDATE - 21',
'GROUP BY ',
'    H.NAME;'))
,p_max_row_count=>20
,p_items_value_column_name=>'HABIT_TOTAL'
,p_items_label_column_name=>'HABIT_NAME'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38775417462642842329)
,p_plug_name=>'Average Habits per Weekday'
,p_title=>'Average Habits per Weekday'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38897997171854851661)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_header=>'Average Habits per Weekday'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(38775417806835842329)
,p_region_id=>wwv_flow_imp.id(38775417462642842329)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(38775419514987842330)
,p_chart_id=>wwv_flow_imp.id(38775417806835842329)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    AVG(COUNT(HL.ID)) OVER (PARTITION BY TO_CHAR(HL.COMPLETED_ON, ''DY'')) AS "HABIT_AVERAGE",',
'    TO_CHAR(HL.COMPLETED_ON, ''DY'') AS "WEEKDAY"',
'FROM ',
'    "HABIT_LOGS" HL',
'GROUP BY ',
'    TO_CHAR(HL.COMPLETED_ON, ''DY'');',
''))
,p_max_row_count=>20
,p_items_value_column_name=>'HABIT_AVERAGE'
,p_items_label_column_name=>'WEEKDAY'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(38775418932814842330)
,p_chart_id=>wwv_flow_imp.id(38775417806835842329)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(38775418378784842330)
,p_chart_id=>wwv_flow_imp.id(38775417806835842329)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp.component_end;
end;
/
