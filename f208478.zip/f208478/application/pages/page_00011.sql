prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38422178159124110674
,p_default_application_id=>208478
,p_default_id_offset=>38766093974777590157
,p_default_owner=>'WKSP_TECWORKSPACE'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Add habit'
,p_alias=>'ADD-HABIT'
,p_page_mode=>'MODAL'
,p_step_title=>'Add habit'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(38898196138102851970)
,p_step_template=>wwv_flow_imp.id(38897894624785851548)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38858515851065946310)
,p_plug_name=>'Actions'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38897997171854851661)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38812532552516255002)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38858515851065946310)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(38898070284701851712)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Save'
,p_button_execute_validations=>'N'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(38812783049551886790)
,p_branch_name=>'Go To Page 20000'
,p_branch_action=>'f?p=&APP_ID.:20000:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40697475937027916203)
,p_name=>'P11_NAME'
,p_is_required=>true
,p_item_sequence=>70
,p_item_default=>'Name of your habit...'
,p_prompt=>'Name '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(38898067871155851710)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40697476062102916204)
,p_name=>'P11_FREQUENCY'
,p_item_sequence=>90
,p_item_default=>'2'
,p_prompt=>'Frequency (days a week)'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(38898067871155851710)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40697476176466916205)
,p_name=>'P11_COLOR'
,p_item_sequence=>100
,p_item_default=>'Grey'
,p_prompt=>'Color'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_lov=>'STATIC:Pink;FFEFF1,Grey;808080'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(38898067871155851710)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'CONTAINS'
,p_attribute_02=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'3'
,p_attribute_09=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40697476242870916206)
,p_name=>'P11_DESCRIPTION'
,p_item_sequence=>80
,p_item_default=>'Description of your habit ...'
,p_prompt=>'Description'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(38898067871155851710)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40712864189041141428)
,p_name=>'P11_PROFILE_PIC'
,p_item_sequence=>60
,p_prompt=>'Image upload'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(38898067570587851709)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'DROPZONE_BLOCK'
,p_attribute_18=>'N'
);
wwv_flow_imp.component_end;
end;
/
