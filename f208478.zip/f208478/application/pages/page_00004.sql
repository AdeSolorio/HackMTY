prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38422178159124110674
,p_default_application_id=>208478
,p_default_id_offset=>38766093974777590157
,p_default_owner=>'WKSP_TECWORKSPACE'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Home'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Categories */',
'.c-Categories {',
'  --a-cv-placeholder-color: transparent; /* Hide Placeholders */',
'  --a-cv-background-color: transparent; /* Remove Card Background */',
'  --a-cv-border-width: 0px; /* Remove Card Borders */',
'  --a-cv-header-padding-y: .5rem;',
'  --a-cv-title-font-size: .875rem;',
'  --a-cv-title-font-weight: 400;',
'  --a-cv-shadow: none;',
'  --a-cv-icon-image-size: 4rem;',
'',
'  min-block-size: 8rem; /* Set Initial Size of Cards */',
'}',
'',
'/* Align Category Image */',
'.c-Categories .a-CardView-iconImg {',
'  margin-inline: auto;',
'}',
'',
'/* Misc Category Styles */',
'.c-Categories .a-CardView-items {',
'  padding-inline: .25rem;',
'  padding-block: 0;',
'  margin-inline: auto;',
'  text-align: center;',
'  inline-size: max-content;',
'}',
'',
'/* Misc Category Item Styles */',
'.c-Categories .a-CardView-item {',
'  flex-shrink: 0;',
'  padding-block: .5rem;',
'  min-inline-size: 0;',
'}',
'',
'/* Set Carousel Aspect Ratio */',
'.t-Region-carouselRegions {',
'  aspect-ratio: 2.5 / 1;',
'  overflow: hidden;',
'}',
'',
'/* Cards */',
'.a-CardView-items {',
'  max-inline-size: 100%;',
'  scrollbar-width: 0;',
'  scroll-snap-type: x mandatory;',
'  overflow-x: auto;',
'  display: flex;',
'  flex-direction: column;',
'}',
'',
'/* Hide Scrollbars for Webkit Browsers */',
'.a-CardView-items::-webkit-scrollbar {',
'  display: none;',
'}',
'',
'.a-CardView-item {',
'  scroll-snap-align: start;',
'  min-inline-size: 17.5rem;',
'  width: 100%;',
'}',
'',
'/* Rating Badge */',
'.a-CardView-badge {',
'  background-color: var(--a-palette-warning-shade);',
'  color: var(--a-palette-warning);',
'}',
'',
'.a-CardView-badgeValue {',
'  color: initial;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38445082829325585637)
,p_plug_name=>'Date Picker'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38897997171854851661)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39079716680045341258)
,p_plug_name=>'Habit List'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38897937664988851604)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    H.ID AS id,',
'    H.NAME AS habit_name,',
'    H.DESCRIPTION,',
'    H.FRECUENCY,',
'    H.COLOR,',
'    HS.ID AS streak_id,',
'    HS.START_DATE,',
'    HS.STREAK_COUNT,',
'    HS.USER_ID,',
'    CASE',
'        WHEN H.ICON IS NOT NULL THEN H.ICON',
'        ELSE NULL',
'    END AS ICON',
'FROM HABITS H',
'LEFT JOIN HABIT_STREAKS HS ON H.ID = HS.HABIT_ID',
'WHERE HS.END_DATE IS NULL;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'This category is empty!'
,p_no_data_found_icon_classes=>'fa-emoji-grin-sweat'
,p_show_total_row_count=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(38812433253999217526)
,p_region_id=>wwv_flow_imp.id(39079716680045341258)
,p_layout_type=>'ROW'
,p_card_css_classes=>'a-CardView-item-mobile rounded rounded-lg'
,p_title_adv_formatting=>false
,p_title_column_name=>'HABIT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if STREAK_COUNT /}',
'  &STREAK_COUNT.-day Streak',
'{else /}',
'  Ready to Start',
'{endif /}'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_css_classes=>'rounded-top rounded-top-lg'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(38445084024695585649)
,p_card_id=>wwv_flow_imp.id(38812433253999217526)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Complete'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_button_display_type=>'TEXT'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(38895842295111924920)
,p_card_id=>wwv_flow_imp.id(38812433253999217526)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>40
,p_label=>'Edit'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3:P3_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38445082748391585636)
,p_name=>'P4_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38445082829325585637)
,p_prompt=>'Date'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(38898067871155851710)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38842757838922882503)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SEND_PUSH_NOTIFICATION'
,p_process_name=>'Send Push Notification'
,p_attribute_01=>'&APP_USER.'
,p_attribute_02=>'Thank you for tracking your habits!'
,p_attribute_03=>'Habit completed.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38842757838922882503
);
wwv_flow_imp.component_end;
end;
/
