prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38422178159124110674
,p_default_application_id=>208478
,p_default_id_offset=>38766093974777590157
,p_default_owner=>'WKSP_TECWORKSPACE'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>'Calendar'
,p_alias=>'CALENDAR'
,p_step_title=>'Calendar'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.fc-event.percentage-100 {',
'    background-color: green;',
'}',
'',
'/* Orange background for less than 70% completion */',
'.fc-event.percentage-70 {',
'    background-color: orange;',
'}',
'',
'/* Yellow background for less than 50% completion */',
'.fc-event.percentage-50 {',
'    background-color: yellow;',
'}',
'',
'.fc-event.percentage-50  > div {',
'	color: black;',
'}',
'',
'/* Red background for less than 25% completion */',
'.fc-event.percentage-25 {',
'    background-color: red;',
'}',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'08'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38445081345464585622)
,p_plug_name=>'Type selector'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(38898006957939851668)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38445081581027585624)
,p_plug_name=>'Yearly'
,p_parent_plug_id=>wwv_flow_imp.id(38445081345464585622)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38897997171854851661)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    TO_CHAR(COMPLETED_ON, ''MM/DD/YYYY'') AS "FORMATTED_DATE",',
'    COMPLETED_ON,',
'    COUNT(*) AS "COUNT"',
'FROM ',
'    "HABIT_LOGS"',
'GROUP BY ',
'    COMPLETED_ON;',
''))
,p_plug_source_type=>'PLUGIN_COM.NIKITSKY.HEATMAP_CALENDAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', '16',
  'attribute_02', 'COMPLETED_ON',
  'attribute_03', 'COUNT',
  'attribute_05', '2024',
  'attribute_06', '1',
  'attribute_08', 'none',
  'attribute_10', 'white',
  'attribute_12', 'blue',
  'attribute_14', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38769684639762047439)
,p_plug_name=>'Monthly'
,p_parent_plug_id=>wwv_flow_imp.id(38445081345464585622)
,p_region_css_classes=>'css_class'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38897997171854851661)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH HabitLogCounts AS (',
'    SELECT ',
'        HL.COMPLETED_ON, ',
'        COUNT(DISTINCT HL.HABIT_ID) AS logged_habits',
'    FROM ',
'        HABIT_LOGS HL',
'    GROUP BY ',
'        HL.COMPLETED_ON',
'),',
'TotalHabits AS (',
'    SELECT COUNT(DISTINCT H.ID) AS total_habits',
'    FROM HABITS H',
')',
'SELECT ',
'    H.NAME AS HABIT_NAME,',
'    HL.COMPLETED_ON,',
'    (LC.logged_habits / TH.total_habits) * 100 AS habit_percentage,',
'    ',
'    CASE',
'        WHEN (LC.logged_habits / TH.total_habits) * 100 = 100 THEN ''percentage-100''',
'        WHEN (LC.logged_habits / TH.total_habits) * 100 < 70 AND (LC.logged_habits / TH.total_habits) * 100 >= 50 THEN ''percentage-70''',
'        WHEN (LC.logged_habits / TH.total_habits) * 100 < 50 AND (LC.logged_habits / TH.total_habits) * 100 >= 25 THEN ''percentage-50''',
'        WHEN (LC.logged_habits / TH.total_habits) * 100 < 25 THEN ''percentage-25''',
'        ELSE ''no-change''',
'    END AS css_class',
'',
'FROM HABIT_LOGS HL',
'JOIN HABITS H ON HL.HABIT_ID = H.ID',
'JOIN HabitLogCounts LC ON HL.COMPLETED_ON = LC.COMPLETED_ON',
'CROSS JOIN TotalHabits TH;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'css_class', 'CSS_CLASS',
  'display_column', 'HABIT_NAME',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '6',
  'multiple_line_event', 'N',
  'show_time', 'N',
  'show_tooltip', 'N',
  'show_weekend', 'Y',
  'start_date_column', 'COMPLETED_ON')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38445082338581585632)
,p_name=>'Apply css class'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(38769684639762047439)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38445082426602585633)
,p_event_id=>wwv_flow_imp.id(38445082338581585632)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(document).ready(function() {',
'    // Iterate through each day in the calendar',
'    $("td.fc-day").each(function() {',
'        var date = $(this).data("date");  // Get the date for each day cell',
'        var habitPercentage = 0;',
'',
'        // You need to fetch the percentage from the backend or assume data is available in the data attributes',
'        // For example, let''s assume you''re setting this attribute in your SQL or dynamically',
'        habitPercentage = $(this).data("habit-percentage");',
'',
'        // Apply class based on percentage ranges',
'        if (habitPercentage === 100) {',
'            $(this).addClass("percentage-100");',
'        } else if (habitPercentage < 70 && habitPercentage >= 50) {',
'            $(this).addClass("percentage-70");',
'        } else if (habitPercentage < 50 && habitPercentage >= 25) {',
'            $(this).addClass("percentage-50");',
'        } else if (habitPercentage < 25 && habitPercentage > 0) {',
'            $(this).addClass("percentage-25");',
'        }',
'    });',
'});',
''))
);
wwv_flow_imp.component_end;
end;
/
