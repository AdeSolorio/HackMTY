prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38422178159124110674
,p_default_application_id=>208478
,p_default_id_offset=>38766093974777590157
,p_default_owner=>'WKSP_TECWORKSPACE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Welcome'
,p_alias=>'WELCOME'
,p_step_title=>'Welcome'
,p_autocomplete_on_off=>'ON'
,p_step_template=>wwv_flow_imp.id(38897905198865851559)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39036635933464328181)
,p_plug_name=>'Background Image'
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(38897967328774851637)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BACKGROUND_IMAGE'
,p_location=>null
,p_region_image=>'#APP_FILES#back2.png'
,p_landmark_type=>'exclude_landmark'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40644612908343935983)
,p_plug_name=>'Welcome Image'
,p_region_css_classes=>'u-flex u-justify-content-center'
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(38897967328774851637)
,p_plug_display_sequence=>20
,p_location=>null
,p_region_image=>'#APP_FILES#People.png'
,p_landmark_type=>'exclude_landmark'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40644613081037935984)
,p_plug_name=>'Welcome Text'
,p_region_css_classes=>'u-textCenter'
,p_region_template_options=>'#DEFAULT#:margin-top-md:margin-bottom-lg'
,p_plug_template=>wwv_flow_imp.id(38897930539364851593)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<p>Become the type of person you want to be!</p>'
,p_landmark_type=>'exclude_landmark'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38812423444337202575)
,p_button_sequence=>40
,p_button_name=>'SELECT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(38898070284701851712)
,p_button_image_alt=>'Select your Archetype'
,p_button_redirect_url=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'mxw320 margin-auto'
,p_grid_new_row=>'Y'
,p_grid_column_span=>4
,p_grid_column=>5
);
wwv_flow_imp.component_end;
end;
/
