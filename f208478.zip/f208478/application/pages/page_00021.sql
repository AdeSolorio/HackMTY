prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38422178159124110674
,p_default_application_id=>208478
,p_default_id_offset=>38766093974777590157
,p_default_owner=>'WKSP_TECWORKSPACE'
);
wwv_flow_imp_page.create_page(
 p_id=>21
,p_name=>'ArchetypesTest'
,p_alias=>'ARCHETYPES1'
,p_step_title=>'Archetypes'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38842758297473882507)
,p_plug_name=>'TEXT'
,p_title=>'Select your archetype!'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useRegionTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38898009539284851670)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source_type=>'NATIVE_HELP_TEXT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77645301408572152411)
,p_plug_name=>'Archetypes'
,p_title=>'Archetypes'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA'
,p_plug_template=>wwv_flow_imp.id(38897937664988851604)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       DESCRIPTION,',
'       COLOR,',
'       IMAGE,',
'       BLOLB,',
'       MIME,',
'       CREATED_DATE,',
'       FILE_NAME,',
'       ''#APP_FILES#'' || IMAGE_SIMPLE AS image_url',
'  from ARCHETYPES'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(38835026696993983120)
,p_region_id=>wwv_flow_imp.id(77645301408572152411)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'DESCRIPTION'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'&IMAGE_URL.'
,p_media_display_position=>'FIRST'
,p_media_sizing=>'FIT'
,p_media_description=>'&NAME.'
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38842758847789882513)
,p_button_sequence=>30
,p_button_name=>'Submit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38898070284701851712)
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38842758615740882511)
,p_name=>'CHECK'
,p_item_sequence=>20
,p_prompt=>'Check'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Prosperous;Prosperous,Balancer;Balancer,Ecoist;Ecoist,Fitness;Fitness,Taskmaster;Taskmaster,Refresher;Refresher,Networker;Networker,Spiritualist;Spiritualist,Climber;Climber,Optimist;Optimist'
,p_colspan=>1
,p_field_template=>wwv_flow_imp.id(38898067871155851710)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38842758794378882512)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SEND_PUSH_NOTIFICATION'
,p_process_name=>'Send Push Notification'
,p_attribute_01=>'&APP_USER.'
,p_attribute_02=>'Archetype selected!'
,p_attribute_03=>'Habits are being updated to target your desired archtype.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(38842758847789882513)
,p_internal_uid=>38842758794378882512
);
wwv_flow_imp.component_end;
end;
/
