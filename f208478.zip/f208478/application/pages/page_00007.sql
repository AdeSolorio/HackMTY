prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38422178159124110674
,p_default_application_id=>208478
,p_default_id_offset=>38766093974777590157
,p_default_owner=>'WKSP_TECWORKSPACE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Item Details'
,p_alias=>'ITEM-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Item Details'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Hero */',
'.c-HeroCard {',
'  --a-cv-placeholder-color: transparent; /* Hide Placeholders */',
'  --a-cv-background-color: transparent; /* Remove Hero Card Background */',
'  --a-cv-border-width: 0px; /* Remove Hero Card Borders */',
'  --a-cv-shadow: none; /* Remove Hero Card Shadow */',
'  --a-cv-media-border-radius: .5rem;',
'  --a-cv-header-padding-x: 0rem;',
'  --a-cv-grid-gap: 0rem;',
'',
'  min-block-size: 15.75rem; /* Set Initial Hero Card Size */',
'}',
'',
'/* Set Hero Card Grid */',
'.a-CardView-items--grid {',
'  grid-template-columns: auto;',
'  padding: 0;',
'}',
'',
'/* Set Max-Height for Hero Card Image */',
'.c-HeroCard .a-CardView-media {',
'  max-block-size: 10rem;',
'}',
'',
'/* Show Only First Hero Card */',
'.c-HeroCard .is-placeholder li:not(:first-child) {',
'  display: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(38897894624785851548)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38812782853702886788)
,p_plug_name=>'Item Information'
,p_region_css_classes=>'c-HeroCard'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleC'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38897937664988851604)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       image_url as image,',
'       name,',
'       description,',
'       price',
'  from sample_restaurant_items',
' where id = :P7_ITEM_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(38812782880514886789)
,p_region_id=>wwv_flow_imp.id(38812782853702886788)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="a-CardView-title">',
'  &NAME.<br />',
'  $&PRICE.',
'</div>'))
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'<div class="a-CardView-subTitle">&DESCRIPTION.</div>'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'#APP_FILES#&IMAGE.'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_media_description=>'&DESCRIPTION.'
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38863995585892946198)
,p_plug_name=>'Actions'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38897997171854851661)
,p_plug_display_sequence=>160
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39752795668012741028)
,p_plug_name=>'Quantity Container'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI:margin-top-sm'
,p_plug_template=>wwv_flow_imp.id(38897933322644851597)
,p_plug_display_sequence=>60
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38812475120485236884)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38863995585892946198)
,p_button_name=>'ADD_CART'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(38898070284701851712)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add to Cart'
,p_button_condition=>'sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) = 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38812476674851236886)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(39752795668012741028)
,p_button_name=>'SUBSTRACT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--pillStart'
,p_button_template_id=>wwv_flow_imp.id(38898070284701851712)
,p_button_image_alt=>'-'
,p_warn_on_unsaved_changes=>null
,p_grid_column_css_classes=>'padding-none u-flex'
,p_grid_new_row=>'Y'
,p_grid_row_css_classes=>'u-flex u-align-items-stretch'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38812475530557236885)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(38863995585892946198)
,p_button_name=>'EDIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(38898070284701851712)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update Cart'
,p_button_condition=>'sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38812475895387236885)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(38863995585892946198)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--danger:t-Button--link:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(38898070284701851712)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Remove from Cart'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38812477112281236887)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(39752795668012741028)
,p_button_name=>'ADD'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--pillEnd'
,p_button_template_id=>wwv_flow_imp.id(38898070284701851712)
,p_button_image_alt=>'+'
,p_warn_on_unsaved_changes=>null
,p_grid_column_css_classes=>'padding-none u-flex'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38812477497745236887)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(39752795668012741028)
,p_button_name=>'SHARE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38898069591944851711)
,p_button_image_alt=>'Share'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-share-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38904731593541512819)
,p_name=>'P7_UTENSILS'
,p_item_sequence=>70
,p_prompt=>'<span class="fa fa-cutlery" aria-hidden="true"></span> Request utensils, etc.'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(38898067871155851710)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38904731624273512820)
,p_name=>'P7_NOTE'
,p_item_sequence=>80
,p_prompt=>'Add Note'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>2
,p_field_template=>wwv_flow_imp.id(38898067871155851710)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39460138125968607732)
,p_name=>'P7_ITEM_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39463472679757678233)
,p_name=>'P7_ITEM_NAME'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39463472752529678234)
,p_name=>'P7_ITEM_DESCRIPTION'
,p_item_sequence=>50
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select description',
'  from sample_restaurant_items',
' where id = :P7_ITEM_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39609239441825288611)
,p_name=>'P7_SHOPPING_CART_ITEMS'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39752800690916741020)
,p_name=>'P7_QUANTITY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(39752795668012741028)
,p_prompt=>'Quantity'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>3
,p_tag_css_classes=>'rounded-none'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_grid_column_css_classes=>'padding-none t-Button--pillEnd'
,p_field_template=>wwv_flow_imp.id(38898067570587851709)
,p_item_css_classes=>'margin-none t-Form-fieldContainer--noPadding rounded-none'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_attribute_01=>'1'
,p_attribute_03=>'center'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(38812481644774236893)
,p_computation_sequence=>10
,p_computation_item=>'P7_QUANTITY'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0 then',
'    return sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID );',
'else',
'    return 1;',
'end if;'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(38812719134250350601)
,p_computation_sequence=>20
,p_computation_item=>'P7_UTENSILS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0 then',
'    return sample_restaurant_manage_orders.get_utensils( p_item_id => :P7_ITEM_ID );',
'else',
'    return ''N'';',
'end if;'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(38812719242574350602)
,p_computation_sequence=>30
,p_computation_item=>'P7_NOTE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0 then',
'    return sample_restaurant_manage_orders.get_note( p_item_id => :P7_ITEM_ID );',
'else',
'    return '''';',
'end if;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38812483892377236895)
,p_name=>'Share Page'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38812477497745236887)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38812484442261236895)
,p_event_id=>wwv_flow_imp.id(38812483892377236895)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHARE'
,p_attribute_01=>'&P7_ITEM_NAME.'
,p_attribute_02=>'I recommend this: &P7_ITEM_DESCRIPTION.'
,p_attribute_03=>'url'
,p_attribute_04=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38812484827590236896)
,p_name=>'Confirm Delete'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38812475895387236885)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38812485282989236896)
,p_event_id=>wwv_flow_imp.id(38812484827590236896)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Confirm to remove from cart'
,p_attribute_03=>'warning'
,p_attribute_06=>'Confirm'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38812485843601236897)
,p_event_id=>wwv_flow_imp.id(38812484827590236896)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'DELETE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38812486274574236897)
,p_name=>'Substract Action'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38812476674851236886)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38812486689671236897)
,p_event_id=>wwv_flow_imp.id(38812486274574236897)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.items.P7_QUANTITY.setValue( Math.max ( parseInt( apex.items.P7_QUANTITY.value ) - 1, 1 ) )'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38812487128791236898)
,p_name=>'Add Action'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38812477112281236887)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38812487600401236898)
,p_event_id=>wwv_flow_imp.id(38812487128791236898)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.items.P7_QUANTITY.setValue( parseInt( apex.items.P7_QUANTITY.value ) + 1 )'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38812481943635236893)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add Item'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) = 0 then',
'    sample_restaurant_manage_orders.add_item( p_item_id  => :P7_ITEM_ID,',
'                                              p_quantity => :P7_QUANTITY,',
'                                              p_utensils => :P7_UTENSILS,',
'                                              p_note     => :P7_NOTE );',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(38812475120485236884)
,p_internal_uid=>46387968857646736
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38812483126841236894)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Edit Item'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0 then',
'    sample_restaurant_manage_orders.remove_item( p_item_id => :P7_ITEM_ID );',
'    sample_restaurant_manage_orders.add_item( p_item_id  => :P7_ITEM_ID,',
'                                              p_quantity => :P7_QUANTITY,',
'                                              p_utensils => :P7_UTENSILS,',
'                                              p_note     => :P7_NOTE );',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(38812475530557236885)
,p_internal_uid=>46389152063646737
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38812482762823236894)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Item'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0 then',
'    sample_restaurant_manage_orders.remove_item( p_item_id => :P7_ITEM_ID );',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(38812475895387236885)
,p_internal_uid=>46388788045646737
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38812482300124236893)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calculate Shopping Cart Items'
,p_process_sql_clob=>':P7_SHOPPING_CART_ITEMS := sample_restaurant_manage_orders.get_quantity;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>46388325346646736
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38812483518782236894)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_01=>'P7_SHOPPING_CART_ITEMS'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>46389544004646737
);
wwv_flow_imp.component_end;
end;
/
